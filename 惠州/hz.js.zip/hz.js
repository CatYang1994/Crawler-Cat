var spider = require('../../spider');
var fs = require("fs");
var async = require('async');
var xlsx = require('node-xlsx');
var cheerio = require('cheerio');
var iconv = require('iconv-lite');
var sheets = '';
var mysql  = require('mysql');
var transcoding = require('../../utf-gbk');
var hzHomeUrl = 'http://bbs.xizi.com/searcher.php';
var headers = {
    'Referer': 'http://bbs.xizi.com/searcher.php',
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36',
}


var verifyhash = '';
function getExcel() {
    sheets = xlsx.parse('hz.xlsx');
    sheets.forEach(function (sheet) {
        // console.log(sheet['data'][0][0]);
        for (var rowId in sheet['data']) {
            schoolIdArray.push(sheet['data'][rowId][0]);
            schoolNameArray.push(sheet['data'][rowId][1]);
            addressArray.push(sheet['data'][rowId][2]);
            longtitudeArray.push(sheet['data'][rowId][3]);
            latitudesArray.push(sheet['data'][rowId][4]);
            areaCodeArray.push(sheet['data'][rowId][5]);
        }
        spider.startworkSecond({'url':hzHomeUrl,'headers':headers},'gbk')
            .then(function (codeData) {
                verifyhash = cheerio.load(codeData)('input[name="verify"]').val();
                searchSchool();
            })

    })
}
var schoolIdArray = [];
var schoolNameArray = [];
var addressArray = [];
var longtitudeArray = [];
var latitudesArray = [];
var areaCodeArray = [];
function getIndex(callback) {
    fs.readFile('index.txt', 'utf8', function(err, data){
        var array = data.split(',');
        // console.log(array[array.length-2]);
        callback(array[array.length-2]);
    });
}
function setIndex(index,callback) {
    var writerStream = fs.createWriteStream('index.txt', {'flags': 'a'});
// 使用 utf8 编码写入数据
    writerStream.write(index+',', 'utf-8');
// 标记文件末尾
    writerStream.on('finish', function () {
        // console.log("写入完成。");
        callback();
    });
    writerStream.end();

    writerStream.on('error', function (err) {
        console.log(err.stack);
    });
}
getExcel();
var headers1 = {
    'Accept' :'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
    // 'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'en,zh;q=0.9,zh-CN;q=0.8',
    'Cache-Control': 'max-age=0',
    'Connection': 'keep-alive',
    'Content-Type': 'application/x-www-form-urlencoded',
    'Host': 'bbs.xizi.com',
    'Origin': 'http://bbs.xizi.com',
    'Referer': 'http://bbs.xizi.com/searcher.php',
    // 'Upgrade-Insecure-Requests': 1,
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36'
}
var schoolName = '';
function searchSchool() {
    getIndex(function (index) {
        var area = ['博罗','惠城','惠东','惠阳','龙门'];
        // schoolName = schoolNameArray[index];
        schoolName = '一中';
        for (var i = 0; i < area.length; i++) {
            schoolName = schoolName.replace(area[i],'');
        }
        schoolName = schoolName.replace('惠州','');
        schoolName = schoolName.replace('市','').replace('区','');

        if (schoolName.indexOf('-') > -1) {
            schoolName = schoolName.split('-')[0];
        }
        if (schoolName.indexOf('(') > -1) {
            schoolName = schoolName.split('(')[0];
        }
        if (schoolName.indexOf('（') > -1) {
            schoolName = schoolName.split('（')[0];
        }
       schoolName = transcoding.utf2gb(escape(schoolName)).toUpperCase()
        var searchUrl = {
            url:'http://bbs.xizi.com/searcher.php',
            headers:headers1,
            method: "POST",
            body:'keyword='+schoolName+'&verify='+verifyhash+'&step=2&type=thread'
        }
        spider.startworkSecond(searchUrl,'gbk')
            .then(function (searchData) {
                // console.log(cheerio.load(searchData)('.main_min dl').eq(0).find('dt a').text());
                var pages = [];
                if (cheerio.load(searchData)('.pages').html() != null) {
                    // console.log(parseInt(cheerio.load(searchData)('.pages>a').eq(-1).text().substring(1).substring(1).substring(1)));
                    for (var i = 1; i < parseInt(cheerio.load(searchData)('.pages>a').eq(-1).text().substring(1).substring(1).substring(1))+1; i++) {
                        pages.push(i);
                    }
                }else {
                    pages.push(1)
                }
                var curr = 1;
                async.eachLimit(pages,1,function (searchSchoolIndex,nextSearchSchoolPage) {
                    spider.startworkSecond({'url':'http://bbs.xizi.com/searcher.php?keyword='+schoolName+'&type=thread&threadrange=1&username=&starttime=&endtime=&fid=&sortby=postdate&page='+searchSchoolIndex},'gbk')
                        .then(function (data) {
                            console.log('共 '+pages.length+' 页');
                            console.log('目前爬取第 '+curr+' 页');
                            // console.log(cheerio.load(data)('.main_min dl').eq(0).find('dt a').text());
                            async.eachLimit(cheerio.load(data)('.main_min dl'),1,function (dlItem,dlNext) {
                                // 判断学校名字和帖子名是否包含
                                console.log(cheerio.load(dlItem)('dt a').text());
                                dlNext();
                            })
                        })
                        .catch(function (err) {
                            console.log('dataErr == '+err)
                        })
                })

            })
            .catch(function (err) {
                console.log(err);
            })
    })
}